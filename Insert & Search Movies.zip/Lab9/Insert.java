// Import required java libraries
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
import java.util.*;

// Extend HttpServlet class
public class Insert extends HttpServlet {

  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
            throws ServletException, IOException{
				
				
      // Set response content type
      response.setContentType("text/html");
		
		//String message = "HelloWorld";
		PrintWriter out = response.getWriter();
		
		String title = request.getParameter("title");
		String year = request.getParameter("year");
		String genre = request.getParameter("genre");
		String director = request.getParameter("director");
		String country = request.getParameter("country");
		String rating = request.getParameter("rating");
		String description = request.getParameter("desc");
		
		
		try{
        Class.forName("com.mysql.jdbc.Driver");
	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lab?" + "user=root&password=web1");
	Statement st = conn.createStatement();
        
String update = "INSERT INTO mov (Title, Year, Genre, Director, Country, Rating, Description)" +
"VALUES(?,?,?,?,?,?,?)";

PreparedStatement preparedStmt = conn.prepareStatement(update);
      preparedStmt.setString (1, title);
      preparedStmt.setString (2, year);
      preparedStmt.setString (3, genre);
      preparedStmt.setString (4, director);
      preparedStmt.setString (5, country);
      preparedStmt.setString (6, rating);
      preparedStmt.setString (5, description);
 
      // execute the preparedstatement
      preparedStmt.execute();

	
				
  }catch(Exception e){}

String form = "<html><body><h4>Successfully Inserted!</h4></body></html>";
out.println(form);
  }

public void destroy()
  {
      // do nothing.
  }

}
  
		