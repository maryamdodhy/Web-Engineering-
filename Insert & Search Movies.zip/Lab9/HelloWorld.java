// Import required java libraries
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

// Extend HttpServlet class
public class HelloWorld extends HttpServlet {

  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
            throws ServletException, IOException{
				
				
      // Set response content type
      response.setContentType("text/html");
		
		String message = "HelloWorld";
		PrintWriter out = response.getWriter();
      String movie = request.getParameter("mov");
	  
		String title="";
				String year="";
						String genre="";
								String director="";
										String country="";
												String rating="";
														String description="";
	try{
        Class.forName("com.mysql.jdbc.Driver");
	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lab?" + "user=root&password=web1");
	Statement st = conn.createStatement();
        
		        String search = "SELECT * FROM mov";

	ResultSet x =  st.executeQuery(search);
        while(x.next()){
	  if(movie.contains(x.getString("Title")) || x.getString("Title").contains(movie)){
			title = (x.getString("Title"));
			year = (x.getString("Year"));
			genre = (x.getString("Genre"));
			director = (x.getString("Director"));
			country = (x.getString("Country"));	
			rating = (x.getString("Rating"));
			description = (x.getString("Description"));

        }		
		}
				
  }catch(Exception e){}
  
  String form = "<html><head>Search</head> <body> <h3 align='centre'> Search Result </h3> <ul> <li> <b>Title: </b>" + title + " </li>" + 
		"<li> <b>Year: </b>" + year + " </li>" + 
		"<li> <b>Genre: </b>" + genre + " </li>" +
		"<li> <b>Director: </b>" + director + " </li>"+
		"<li> <b>Country: </b>" + country + " </li>"+
		"<li> <b>Rating: </b>" + rating + " </li>"+
		"<li> <b>Description: </b>" + description + " </li>"+
		
		"</ul></body></html>";
  
 out.println(form);
			}
  
  public void destroy()
  {
      // do nothing.
  }
}