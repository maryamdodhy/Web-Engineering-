import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

public class Movie {

   
    public static void main(String[] args) {
        
        Scanner inp = new Scanner (System.in);
        System.out.print("Press 1 to view everything.\n");
        System.out.print("Press 2 to delete a record.\n");
        System.out.print("Press 3 to search a record.\n");     
        
        int op;
        op = inp.nextInt();
        
        
        
        try{
        Class.forName("com.mysql.jdbc.Driver");
	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/movieshub?" + "user=root&password=web1");
	Statement st = conn.createStatement();
        
        if(op == 1){
        
        ResultSet mar = st.executeQuery("SELECT * FROM movie");
        
	while(mar.next())
        {
	System.out.print(mar.getInt(1)+" :  ");	
        System.out.print(mar.getString(2) + " -> Actors: ");
        System.out.print(mar.getString(3) + " -> Director: ");       	
        System.out.print(mar.getString(4));
        System.out.println();
	}
        }
        
        if(op==2){
        
            System.out.print("Which movie do you want to delete?");
        String name;
        name = inp.next();
        
        st = conn.createStatement();
        
        String display ="DELETE FROM movie " +
                "WHERE Movie_Name =\"" +name+ "\"";
        st.executeUpdate(display);
        
        ResultSet mar = st.executeQuery("SELECT * FROM movie");
        
        System.out.print("The movie has been deleted. This is the new list.\n");
        
	while(mar.next())
        {
	System.out.print(mar.getInt(1)+" :  ");	
        System.out.print(mar.getString(2) + " -> Actors: ");
        System.out.print(mar.getString(3) + " -> Director: ");       	
        System.out.print(mar.getString(4));
        System.out.println();
	}
        
        }
        
        if(op==3){
        
        System.out.print("Which movie do you want to search?");
        String mov;
        mov = inp.next();
        st = conn.createStatement();
        String search = "SELECT * FROM movie " +
                "WHERE Movie_Name =\"" +mov+ "\"";
        
       ResultSet x =  st.executeQuery(search);
        while(x.next()){
        System.out.print(x.getInt(1)+" :  ");	
        System.out.print(x.getString(2) + " -> Actors: ");
        System.out.print(x.getString(3) + " -> Director: ");       	
        System.out.print(x.getString(4));
        System.out.println();

        }
        }
    }catch (ClassNotFoundException | SQLException ex){
    System.out.println("Exception..."+ex.getMessage());
    }
    
    }
    
}