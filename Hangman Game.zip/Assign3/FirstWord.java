// Import required java libraries
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import javax.servlet.ServletContext;

// Extend HttpServlet class
public class FirstWord extends HttpServlet {
public static String word;
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
            throws ServletException, IOException
  {
	  
	  System.out.println("hello");
	  
	  PrintWriter out = response.getWriter();
		
	   String randomWord = request.getParameter("randomWord");
	   
	   

		if(randomWord.equals("randWord")){
			
			Class FirstWord = getClass();
	  File f = new File(FirstWord.getClassLoader().getResource("Dictionary.txt").getPath().replaceAll("%20", " "));
		Scanner s = new Scanner(f);
		String guess_word="";
	  
		ArrayList<String> list = new ArrayList<String>();
		while (s.hasNext()){
		list.add(s.next());
		}
		s.close();
	  
		int rand_num = (int)((Math.random()*25143) +1);
		
		guess_word = list.get(rand_num);
		guess_word = guess_word.toLowerCase();
		
		word = guess_word;
		out.write(guess_word);
		out.close();
			
		}
		
		if(randomWord.equals("checkW")){
			
				String alpha = request.getParameter("alpha");
				String word_length = request.getParameter("word_length");
		
			PrintWriter pout = response.getWriter();
			
			char[] char_array = word.toCharArray();
			char[] alpha_array = alpha.toCharArray();
			
			char[] word_array = word_length.toCharArray();
			
			
			for(int i=0; i<word.length();i++){
			
			
				if(alpha_array[0]==char_array[i]){
					
					word_array[i*2] = char_array[i];
					
				}
				
			}
			
			String words = new String(word_array);
			
			

			pout.write(words);
			pout.close();
		}
	
      
  }
 
  public void destroy()
  {
      // do nothing.
  }
}